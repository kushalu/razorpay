const express = require("express");

const { payResponse, userDetails } = require("../controllers/payment");

const router = express.Router();
console.log("inside routess");

router.post("/pay/:use", userDetails);

router.param("use", payResponse);

module.exports = router;
