console.log("inside controllers");
var Razorpay = require("razorpay");
var CryptoJS = require("crypto-js"); // to convert sha 256
const Payment = require("../models/payment");
let instance = new Razorpay({
  key_id: "rzp_test_5iqD9AyAWmz7MB", // your `KEY_ID`
  key_secret: "rweHiWjIoxqY9S8UJzotVvze", // your `KEY_SECRET`
});

exports.payResponse = async (req, res, next) => {
  try {
    params = {
      amount: req.body.amount,
    };
    var result = await instance.orders.create(params);

    if (result.amout === " ") {
      res.status(400).json("error while initiating data  ");
    } else if (result.id === " ") {
      res.status(400).json("Failed to initaie order Id ");
    } else {
      req.payment = result;
      next();
    }
  } catch (e) {
    res.status(500).json(e);
  }
};

exports.userDetails = async (req, res) => {
  try {
    var oid = CryptoJS.AES.encrypt(req.payment.id, "secret key 123").toString();
    var params = {
      name: req.body.name,
      email: req.body.email,
      phnumber: req.body.phnumber,
      orderid: oid,
      entity: req.payment.entity,
      amount: req.payment.amount,
      amount_paid: req.payment.amount,
      currency: req.payment.currency,
      receipt: req.payment.receipt,
    };
    console.log(params);
    const pay = await new Payment(params);
    await pay.save();
    res.status(200).json({ message: "Payment initialted .", pay });
  } catch (e) {
    res.status(500).json(e);
  }
};
