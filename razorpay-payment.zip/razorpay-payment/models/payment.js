const mongoose = require("mongoose");
const { ObjectId } = mongoose.Schema;

const paymentSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  phnumber: {
    type: Number,
    required: true,
  },
  orderid: {
    type: String,
    required: true,
  },
  entity: {
    type: String,
    required: true,
  },
  amount: {
    type: Number,
    required: true,
  },
  amount_paid: {
    type: Number,
  },
  amount_due: {
    type: Number,
  },
  currency: {
    type: String,
  },
  receipt: {
    type: String,
  },
  created: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model("Payment", paymentSchema);
