const express = require("express");
const app = express();
const mongoose = require("mongoose");

const bodyParser = require("body-parser");

// const fs = require("fs");
const cors = require("cors");
const dotenv = require("dotenv");
dotenv.config();

// db

mongoose

  .connect("mongodb://localhost/razorpay", { useNewUrlParser: true })
  // connect("mongodb://kun:kun@123@ds141168.mlab.com:41168/microservices", {
  //   useNewUrlParser: true,
  // })
  .then(() => console.log("DB Connected"));

const paymentRoutes = require("./routes/payment");
// apiDocs
app.get("/", (req, res) => {
  fs.readFile("docs/apiDocs.json", (err, data) => {
    if (err) {
      res.status(400).json({
        error: err,
      });
    }
    const docs = JSON.parse(data);
    res.json(docs);
  });
});
app.post("/payment", (req, res) => {
  console.log("hello");
});

// middleware -
// app.use(morgan("dev"));
app.use(bodyParser.json());

app.use(cors());

app.use("", paymentRoutes);

app.use(function (err, req, res, next) {
  if (err.name === "UnauthorizedError") {
    res.status(401).json({ error: "Unauthorized!" });
  }
});

const port = process.env.PORT || 8080;
app.listen(port, () => {
  console.log(`A Node Js API is listening on port: ${port}`);
});
